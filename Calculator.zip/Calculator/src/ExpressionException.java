public class ExpressionException extends Exception {
    public String toString() {
        return "Incorrect Expression";
    }
}
